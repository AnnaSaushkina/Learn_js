console.log(123)

const x = 1

export {}
