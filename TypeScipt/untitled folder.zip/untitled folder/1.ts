export {}

const x: number = 1

const name1: string = "Alex"
const names: string[] = ["A", "B"]

const isAdult: boolean = true

function sum(a: number, b: number) {
  console.log(a + b)
}

// sum(1, "1")

const nums: number[] = [1, 2, 3, 4]

const newNums = nums.filter((x) => x < 4)
const newNums2 = myFilter(nums, (x) => x < 4)

function myFilter(nums: number[], isOk: any) {
  const result = [] // 1, 2

  if (isOk(1) == true) {
    result.push(1)
  }

  if (isOk(2) == true) {
    result.push(2)
  }
}

// function test(arg1: any) {}

// test(1)
// test('2')
// test([])

// [1, 2, 3]
// fn(1) -> true
// fn(2) -> true
// fn(3) -> true
// fn(4) -> true

console.log(newNums)
console.log(newNums2)
